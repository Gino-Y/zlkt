<template>
  <router-view></router-view>
</template>

<script>
export default {
  name: 'App',
  components: {}
}
</script>

<style>
body, ul{
  margin: 0;
  padding: 0;
}
*, *:before, *:after{
  box-sizing: border-box;
}
</style>