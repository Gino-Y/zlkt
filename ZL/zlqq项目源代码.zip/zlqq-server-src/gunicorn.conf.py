worker_class = "eventlet"
workers = 1
bind = "0.0.0.0:5000"
accesslog = "/home/hynever/zlqq/log/access.log"
errorlog = "/home/hynever/zlqq/log/error.log"
daemon = True